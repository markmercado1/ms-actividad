export enum EventModality {
  PRESENCIAL = 'PRESENTIAL',
  VIRTUAL = 'VIRTUAL',
  HIBRIDO = 'HYBRID'
}
