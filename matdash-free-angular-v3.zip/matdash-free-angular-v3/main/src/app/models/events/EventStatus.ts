export enum EventStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE'
}
