export enum EventType {
  FREE = 'FREE',
  PAID = 'PAID',

}
