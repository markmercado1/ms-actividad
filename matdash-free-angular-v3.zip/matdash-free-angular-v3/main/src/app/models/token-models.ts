export class TokenModels {
  token?: string;
}
