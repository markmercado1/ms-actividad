export interface ParticipantDTO {
  participantId: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  registrationDate: string;
}
