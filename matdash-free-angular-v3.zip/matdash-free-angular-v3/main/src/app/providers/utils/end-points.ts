export const END_POINTS = {
  category: 'categoria',
  login: 'auth/login',
};
