export const environment = {
  production: false,
  url: "http://localhost:9095/",
};
