import {
  InjectionToken
} from "./chunk-TOULDFTB.js";

// node_modules/@angular/material/fesm2022/input-value-accessor.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-KWWNVIZX.js.map
