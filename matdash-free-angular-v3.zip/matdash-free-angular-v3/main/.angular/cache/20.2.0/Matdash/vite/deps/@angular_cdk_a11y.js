import {
  A11yModule,
  ActiveDescendantKeyManager,
  AriaDescriber,
  CDK_DESCRIBEDBY_HOST_ATTRIBUTE,
  CDK_DESCRIBEDBY_ID_PREFIX,
  CdkAriaLive,
  CdkMonitorFocus,
  CdkTrapFocus,
  ConfigurableFocusTrap,
  ConfigurableFocusTrapFactory,
  EventListenerFocusTrapInertStrategy,
  FOCUS_MONITOR_DEFAULT_OPTIONS,
  FOCUS_TRAP_INERT_STRATEGY,
  FocusKeyManager,
  FocusMonitor,
  FocusMonitorDetectionMode,
  FocusTrap,
  FocusTrapFactory,
  HighContrastMode,
  HighContrastModeDetector,
  INPUT_MODALITY_DETECTOR_DEFAULT_OPTIONS,
  INPUT_MODALITY_DETECTOR_OPTIONS,
  InputModalityDetector,
  InteractivityChecker,
  IsFocusableConfig,
  LIVE_ANNOUNCER_DEFAULT_OPTIONS,
  LIVE_ANNOUNCER_ELEMENT_TOKEN,
  LIVE_ANNOUNCER_ELEMENT_TOKEN_FACTORY,
  ListKeyManager,
  LiveAnnouncer,
  MESSAGES_CONTAINER_ID,
  NOOP_TREE_KEY_MANAGER_FACTORY,
  NOOP_TREE_KEY_MANAGER_FACTORY_PROVIDER,
  NoopTreeKeyManager,
  TREE_KEY_MANAGER,
  TREE_KEY_MANAGER_FACTORY,
  TREE_KEY_MANAGER_FACTORY_PROVIDER,
  TreeKeyManager,
  addAriaReferencedId,
  getAriaReferenceIds,
  removeAriaReferencedId
} from "./chunk-DPRFQZD5.js";
import "./chunk-OB4BY745.js";
import "./chunk-R4DALVGK.js";
import "./chunk-AQTVNIXX.js";
import {
  _IdGenerator,
  isFakeMousedownFromScreenReader,
  isFakeTouchstartFromScreenReader
} from "./chunk-OKKSGZRX.js";
import "./chunk-5JKFW7ED.js";
import "./chunk-2ZKSKDON.js";
import "./chunk-Y5WJIVYK.js";
import "./chunk-YDR5LZCI.js";
import "./chunk-224KHV3X.js";
import "./chunk-B6FTSS77.js";
import "./chunk-CSPLI7JI.js";
import "./chunk-TOULDFTB.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-MARUHEWW.js";
import "./chunk-C42J3HML.js";
export {
  A11yModule,
  ActiveDescendantKeyManager,
  AriaDescriber,
  CDK_DESCRIBEDBY_HOST_ATTRIBUTE,
  CDK_DESCRIBEDBY_ID_PREFIX,
  CdkAriaLive,
  CdkMonitorFocus,
  CdkTrapFocus,
  ConfigurableFocusTrap,
  ConfigurableFocusTrapFactory,
  EventListenerFocusTrapInertStrategy,
  FOCUS_MONITOR_DEFAULT_OPTIONS,
  FOCUS_TRAP_INERT_STRATEGY,
  FocusKeyManager,
  FocusMonitor,
  FocusMonitorDetectionMode,
  FocusTrap,
  FocusTrapFactory,
  HighContrastMode,
  HighContrastModeDetector,
  INPUT_MODALITY_DETECTOR_DEFAULT_OPTIONS,
  INPUT_MODALITY_DETECTOR_OPTIONS,
  InputModalityDetector,
  InteractivityChecker,
  IsFocusableConfig,
  LIVE_ANNOUNCER_DEFAULT_OPTIONS,
  LIVE_ANNOUNCER_ELEMENT_TOKEN,
  LIVE_ANNOUNCER_ELEMENT_TOKEN_FACTORY,
  ListKeyManager,
  LiveAnnouncer,
  MESSAGES_CONTAINER_ID,
  NOOP_TREE_KEY_MANAGER_FACTORY,
  NOOP_TREE_KEY_MANAGER_FACTORY_PROVIDER,
  NoopTreeKeyManager,
  TREE_KEY_MANAGER,
  TREE_KEY_MANAGER_FACTORY,
  TREE_KEY_MANAGER_FACTORY_PROVIDER,
  TreeKeyManager,
  _IdGenerator,
  addAriaReferencedId,
  getAriaReferenceIds,
  isFakeMousedownFromScreenReader,
  isFakeTouchstartFromScreenReader,
  removeAriaReferencedId
};
