// node_modules/@angular/cdk/fesm2022/array.mjs
function coerceArray(value) {
  return Array.isArray(value) ? value : [value];
}

export {
  coerceArray
};
//# sourceMappingURL=chunk-2ZKSKDON.js.map
