import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger
} from "./chunk-WQ5FOKM4.js";
import "./chunk-AUEEBM7X.js";
import "./chunk-XA3EVXH3.js";
import "./chunk-54B242XI.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-J67JZ5J2.js";
import "./chunk-2MZALPXC.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-WDHQBVLJ.js";
import "./chunk-WGRTNBQC.js";
import "./chunk-WVBMOKKF.js";
import "./chunk-AWRCRY4Q.js";
import "./chunk-RXXZTEFO.js";
import "./chunk-WDORLV2S.js";
import "./chunk-PASJCZHW.js";
import "./chunk-3JC5WV2T.js";
import "./chunk-CN7VHKLT.js";
import "./chunk-6VB4ITYR.js";
import "./chunk-OX3NRC6A.js";
import "./chunk-VENV3F3G.js";
import "./chunk-L2BZS5YT.js";
import "./chunk-U7QR5LXD.js";
import "./chunk-ODRCYIL4.js";
import "./chunk-U7XY7Q7Q.js";
import "./chunk-DPRFQZD5.js";
import "./chunk-OB4BY745.js";
import "./chunk-R4DALVGK.js";
import "./chunk-H6VIOWWK.js";
import "./chunk-AQTVNIXX.js";
import "./chunk-OKKSGZRX.js";
import "./chunk-5JKFW7ED.js";
import "./chunk-2ZKSKDON.js";
import "./chunk-Y5WJIVYK.js";
import "./chunk-ECRVJYHP.js";
import "./chunk-7M6T2CZT.js";
import "./chunk-7UJZXIJQ.js";
import "./chunk-UG4C7YLC.js";
import "./chunk-YDR5LZCI.js";
import "./chunk-224KHV3X.js";
import "./chunk-B6FTSS77.js";
import "./chunk-CSPLI7JI.js";
import "./chunk-TOULDFTB.js";
import "./chunk-HWYXSU2G.js";
import "./chunk-JRFR6BLO.js";
import "./chunk-MARUHEWW.js";
import "./chunk-C42J3HML.js";

// node_modules/@angular/material/fesm2022/select.mjs
var matSelectAnimations = {
  // Represents
  // trigger('transformPanel', [
  //   state(
  //     'void',
  //     style({
  //       opacity: 0,
  //       transform: 'scale(1, 0.8)',
  //     }),
  //   ),
  //   transition(
  //     'void => showing',
  //     animate(
  //       '120ms cubic-bezier(0, 0, 0.2, 1)',
  //       style({
  //         opacity: 1,
  //         transform: 'scale(1, 1)',
  //       }),
  //     ),
  //   ),
  //   transition('* => void', animate('100ms linear', style({opacity: 0}))),
  // ])
  /** This animation transforms the select's overlay panel on and off the page. */
  transformPanel: {
    type: 7,
    name: "transformPanel",
    definitions: [
      {
        type: 0,
        name: "void",
        styles: {
          type: 6,
          styles: { opacity: 0, transform: "scale(1, 0.8)" },
          offset: null
        }
      },
      {
        type: 1,
        expr: "void => showing",
        animation: {
          type: 4,
          styles: {
            type: 6,
            styles: { opacity: 1, transform: "scale(1, 1)" },
            offset: null
          },
          timings: "120ms cubic-bezier(0, 0, 0.2, 1)"
        },
        options: null
      },
      {
        type: 1,
        expr: "* => void",
        animation: {
          type: 4,
          styles: { type: 6, styles: { opacity: 0 }, offset: null },
          timings: "100ms linear"
        },
        options: null
      }
    ],
    options: {}
  }
};
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
